import numpy as np
from numpy.random import rand
from function import Fun
# import FS.functionHO
import BHRO as h_bhro
import math
import copy
import math
import numpy as np
from scipy.special import gamma
import matplotlib.pyplot as plt

# 初始化位置
def init_position(lb, ub, N, dim):
    X = np.zeros([N, dim], dtype='float')
    for i in range(N):
        for d in range(dim):
            X[i, d] = lb[0, d] + (ub[0, d] - lb[0, d]) * rand()
    return X


# 设置边界
def boundary(x, lb, ub):  # lb下界，ub上界
    if x < lb:
        x = lb
    if x > ub:
        x = ub

    return x

def levy_flight(dim):
    beta = 1.5
    sigma = (gamma(1 + beta) * np.sin(np.pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = np.random.randn(1, dim) * sigma
    v = np.random.randn(1, dim)
    step = u / np.abs(v) ** (1 / beta)
    return step

def ao(xtrain, ytrain, opts):
    # Dimension
    dim = 6
    # Parameters
    ub = [0.1, 0.6, 200, 200, 256, 100]
    lb = [0.0001, 0, 10, 10, 32, 10]
    ub = np.array(ub)
    ub = ub.reshape((1, dim))

    lb = np.array(lb)
    lb = lb.reshape((1, dim))

    N = opts['N']
    max_iter = opts['T']
    # N=3
    # max_iter = 5

    # Initialize position
    X = init_position(lb, ub, N, dim)

    fit = np.zeros([N, 1], dtype='float')

    report = {}
    for i in range(N):
        result = Fun(xtrain, ytrain, X[i, :], opts)
        fit[i, 0] = result['MSE']

    # Pre
    curve = np.zeros([1, max_iter], dtype='float')
    t = 0

    # X = np.hstack((X, fit))
    # groupSize = int(N / 3)
    # max_trial = 15

    # X = X[np.lexsort(X.T)]

    fitness = fit.copy()
    # fitness = fitness.reshape((N, 1))


    # X = X[:, 0:-1]
    Best_P = np.zeros([1, dim], dtype='float')
    Best_P[0, :] = X[0, :]
    best_fit = fitness[0]
    # trial_population = np.zeros([N, 1], dtype='float')  # 自交次数

    Xnew = np.zeros([1, dim], dtype='float')
   

    curve[0, t] = best_fit.copy()
    print("Iteration:", t + 1)
    print("Best (AO):", curve[0, t])
    t += 1

    alpha = 0.1
    delta = 0.1
    
    while t < max_iter:
        G2 = 2 * np.random.rand() - 1
        G1 = 2 * (1 - (t / max_iter))
        to = np.arange(1, dim + 1)
        u = 0.00565
        r0 = 10
        r = r0 + u * to
        omega = 0.005
        phi0 = 3 * np.pi / 2
        phi = -omega * to + phi0
        x = r * np.sin(phi)
        y = r * np.cos(phi)
        QF = t ** ((2 * np.random.rand() - 1) / (1 - max_iter) ** 2)
        for i in range(N):
            if t < int(max_iter/3*2):
                if np.random.rand() < 0.5:
                    mean = np.mean(X,axis=0)
                    Xnew[0, :] = Best_P[0, :] * (1 - t / max_iter) + (mean - Best_P[0, :]) * np.random.rand()
                else:
                    LF = levy_flight(dim)
                    # r = np.floor(N * np.random.rand()).astype(int)
                    r = np.random.randint(0, N)
                    for d in range(dim):
                        Xnew[0, d] = Best_P[0, d] * LF[0, d] + X[r, d] + (y[d] - x[d]) * np.random.rand()
            else:
                if np.random.rand() < 0.5:
                    Xnew[0, :] = (Best_P[0, :] - np.mean(X, axis=0)) * alpha - np.random.rand(dim) + ((ub[0, :] - lb[0, :]) * np.random.rand() + lb[0, :]) * delta
                else:
                    Xnew[0, :] = QF * Best_P[0, :] - (G2 * X[i, :] * np.random.rand()) - G1 * levy_flight(dim) + np.random.rand(dim) * G2
            for d in range(dim):
                Xnew[0, d] = boundary(X[i, d], lb[0, d], ub[0, d])

            result = Fun(xtrain, ytrain, Xnew[0, :], opts)
            Xnew_fit = result['MSE']
            if Xnew_fit < fitness[i]:
                X[i, :] = Xnew[0, :]
                fitness[i] = Xnew_fit
                if fitness[i] < best_fit:
                    Best_P[0, :] = X[i, :]
                    best_fit = fitness[i]
                    report = result.copy()
                    print(i)


       
       


        curve[0, t] = best_fit.copy()
        print("Iteration:", t + 1)
        print("Best (AO):", curve[0, t])
        t += 1

    report['params'] = Best_P

    report['c'] = curve

    return report

import numpy as np
from numpy.random import rand
from function import Fun
# import FS.functionHO
import BHRO as h_bhro
import math
import copy
import math
import numpy as np
from scipy.special import gamma
import matplotlib.pyplot as plt

# 初始化位置
def init_position(lb, ub, N, dim):
    X = np.zeros([N, dim], dtype='float')
    for i in range(N):
        for d in range(dim):
            X[i, d] = lb[0, d] + (ub[0, d] - lb[0, d]) * rand()
    return X


# 设置边界
def boundary(x, lb, ub):  # lb下界，ub上界
    if x < lb:
        x = lb
    if x > ub:
        x = ub

    return x


def clhro(xtrain, ytrain, opts):
    # Parameters
    # Dimension
    dim = 6
    # Parameters
    ub = [0.01,0.5,120,120,128,120]
    lb = [0.001,0,50,50,16,120]
    ub = np.array(ub)
    ub = ub.reshape((1, dim))

    lb = np.array(lb)
    lb = lb.reshape((1, dim))

    N = opts['N']
    max_iter = opts['T']

    # Initialize position
    X = init_position(lb, ub, N, dim)

    fit = np.zeros([N, 1], dtype='float')

    report = {}
    for i in range(N):
        result = Fun(xtrain, ytrain, X[i, :], opts)
        report = result.copy()
        fit[i, 0] = result['MSE']

    # Pre
    curve = np.zeros([1, max_iter], dtype='float')
    t = 0

    X = np.hstack((X, fit))
    groupSize = int(N / 3)
    max_trial = 15

    X = X[np.lexsort(X.T)]

    fitness = X[:, -1]
    fitness = fitness.reshape((N, 1))


    X = X[:, 0:-1]
    best_rice = np.zeros([1, dim], dtype='float')
    best_rice[0, :] = X[0, :]
    best_fit = fitness[0]
    trial_population = np.zeros([N, 1], dtype='float')  # 自交次数

    trial_rice = np.zeros([1, dim], dtype='float')
    sterile = np.zeros([1, dim], dtype='float')
    maintainer = np.zeros([1, dim], dtype='float')
    neighbor = np.zeros([1, dim], dtype='float')

    curve[0, t] = best_fit.copy()
    print("Iteration:", t + 1)
    print("Best (CLHRO):", curve[0, t])
    t += 1

    while t < max_iter:
        # 保持系更新
        for i in range(0, groupSize):
            beta = 3 / 2
            alpha_u = math.pow((gamma(1 + beta) * math.sin(math.pi * beta / 2) / (
                gamma(((1 + beta) / 2) * beta * math.pow(2, (beta - 1) / 2)))), (1 / beta))
            alpha_v = 1

            for j in range(dim):
                u = np.random.normal(0, alpha_u, 1)
                v = np.random.normal(0, alpha_v, 1)
                step = u / math.pow(abs(v), (1 / beta))
                s1 = 1 / (1 + np.exp(-2 * step))
                trial_rice[0, j] = X[i, j] + s1
                trial_rice[0, j] = boundary(trial_rice[0, j], lb[0, j], ub[0, j])

            result = Fun(xtrain, ytrain, trial_rice[0, :], opts)
            trial_rice_fitness = result['MSE']

            if trial_rice_fitness < fitness[i]:
                X[i, :] = trial_rice[0, :]
                fitness[i] = trial_rice_fitness
                if fitness[i] < best_fit:
                    best_rice[0, :] = X[i, :]
                    best_fit = fitness[i]
                    report = result.copy()
                    print(i)


        # 保持系和不育系杂交
        for k in range(2 * groupSize, N):

            maintainer = X[h_bhro.select(0, groupSize, size=1, excludes=[k])]
            sterile = X[h_bhro.select(2 * groupSize, N, size=1, excludes=[k])]  # 不育系

            for j in range(dim):
                flag = 1
                while flag:
                    r1 = np.random.uniform(0, 1)
                    r2 = np.random.uniform(0, 1)
                    if r1 + r2 != 0:  # 设置不为0的情况
                        flag = 0

                trial_rice[0, j] = (r1 * maintainer[j] + r2 * sterile[j]) / (
                        r1 + r2)  # 该公式存在问题，默认为如r2为1-r1
                trial_rice[0, j] = boundary(trial_rice[0, j], lb[0, j], ub[0, j])
            result = Fun(xtrain, ytrain, trial_rice[0, :], opts)
            trial_rice_fitness = result['MSE']

            if trial_rice_fitness < fitness[k]:
                X[k] = trial_rice
                fitness[k] = trial_rice_fitness
                if fitness[k] < best_fit:
                    best_rice[0, :] = X[k, :]
                    best_fit = fitness[k]
                    report = result.copy()
                    print(k)

        # 恢复系自交
        for a in range(groupSize, 2 * groupSize):
            if trial_population[a] < max_trial:
                for j in range(dim):
                    neighbor[0, j] = X[h_bhro.select(groupSize, 2 * groupSize, size=1, excludes=[a]), j]
                    r3 = np.random.uniform(0, 1)
                    trial_rice[0, j] = r3 * (best_rice[0, j] - neighbor[0, j]) + X[a, j]  # 该公式正确
                    trial_rice[0, j] = boundary(trial_rice[0, j], lb[0, j], ub[0, j])

                result = Fun(xtrain, ytrain, trial_rice[0, :], opts)
                trial_rice_fitness = result['MSE']

                if trial_rice_fitness < fitness[a]:
                    X[a] = trial_rice
                    fitness[a] = trial_rice_fitness
                    trial_population[a] = 0
                    if fitness[a] < best_fit:
                        best_rice[0, :] = X[a, :]
                        best_fit = fitness[a]
                        report = result.copy()
                        print(a)
                else:
                    trial_population[a] += 1
            else:
                print("执行重置操作")

                for b in range(dim):
                    r4 = np.random.random()
                    Xc = 0.02  #0.0001
                    Pc = 0.3
                    C4 = np.random.random()
                    if (C4 <= Pc):
                        P_C4 = 1
                    else:
                        P_C4 = 0
                    if (C4 >= 0.5):
                        sign_C4 = -1
                    else:
                        sign_C4 = 1
                    craze = P_C4 * sign_C4 * Xc
                    X[a, b] = r4 * (ub[0, b] - lb[0, b]) + craze * X[a, b] + lb[0, b]  # 该公式正确
                    X[a, b] = boundary(X[a, b], lb[0, b], ub[0, b])

                result = Fun(xtrain, ytrain, X[a, :], opts)
                fitness[a] = result['MSE']
                trial_population[a] = 0
                if fitness[a] < best_fit:
                    best_rice[0, :] = X[a, :]
                    best_fit = fitness[a]
                    report = result.copy()
                    print(a)


        trial_population = trial_population.reshape((N, 1))
        X = np.hstack((X, trial_population))
        X = np.hstack((X, fitness))
        X = X[np.lexsort(X.T)]
        fitness = X[:, -1]
        fitness = fitness.reshape((N, 1))
        X = X[:, 0:-1]
        trial_population = X[:, -1]
        trial_population = trial_population.reshape((N, 1))
        X = X[:, 0:-1]


        curve[0, t] = best_fit.copy()
        print("Iteration:", t + 1)
        print("Best (CLHRO):", curve[0, t])
        t += 1

    report['params'] = best_rice

    report['c'] = curve

    return report

import pandas as pd
import matplotlib.pyplot as plt  # 用来绘图的库
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
from math import sqrt
from sklearn.ensemble import AdaBoostRegressor
from   keras.models import Sequential
from  keras.layers import Dense
from keras.layers import LSTM
from keras.layers import LSTM,Dense,Dropout,Activation
from  keras import optimizers
# from svm import SVR
from sklearn.svm import SVR
import numpy as np
import re
import os
import csv

#计算模型预测效果的评价指标
def calcul_indicator(y,yhat):
    EV = 1 - np.var(y - yhat)/np.var(y)
    MAE = np.sum(np.abs((y - yhat)))/len(y)
    MSE = np.sum(np.multiply((y - yhat),(y - yhat)))/len(y)
    RMSE = sqrt(MSE)
    R_square = 1 - (((y - yhat)**2).sum())/(((y - y.mean())**2).sum())
    report = {'EV':EV,'MAE':MAE,'MSE':MSE,'RMSE':RMSE,'R_square':R_square}
    # return [EV,MAE,MSE,RMSE,R_square]
    return report


#训练LSTM并评估性能
def Fun(x_train,y_train, x, opts):
    n_train_hours = int(x_train.shape[0] * 0.7)
    #将70%的数据用于训练
    train_X = x_train[:n_train_hours:]
    #提取训练集测试数据
    test_X = x_train[n_train_hours:, :]
    train_y = y_train[:n_train_hours]
    #提取训练集标签数据
    test_y = y_train[n_train_hours:]
    # train_X, train_y = train[:, :-1], train[:, -1]
    # test_X, test_y = test[:, :-1], test[:, -1]
    learning_rate = x[0]
    dropout = x[1]
    neurons1 = int(x[2])
    neurons2 = int(x[3])
    batch_size = int(x[4])
    epochs = int(x[5])

    #learning_rate = 0.01
    #dropout = 0.1
    #neurons1 = 60
    #neurons2 = 60
    #batch_size = 32
    #epochs = 30

    # 将数据转换成3D进行输入
    train_X_LSTM = train_X.reshape((train_X.shape[0], 1, train_X.shape[1]))
    test_X_LSTM = test_X.reshape((test_X.shape[0], 1, test_X.shape[1]))
    z = train_X_LSTM.shape[1]
    c = train_X_LSTM.shape[2]
    
    model = Sequential()#创建一个顺序模型
    model.add(LSTM(neurons1, input_shape=(train_X_LSTM.shape[1], train_X_LSTM.shape[2]),return_sequences=True))
    #添加第一层LSTM，指定输入形状
    model.add(Dropout(dropout))
    #添加dropout层
    model.add(LSTM(neurons2, return_sequences=False))
    #添加第二层LSTM
    model.add(Dropout(dropout))
    model.add(Dense(1))
    #添加全连接层，输出一个值


    # Compile model
    # learning_rate = 0.00045
    decay_rate = learning_rate / 100 #计算衰减率
    momentum = 0.5 #设置动量
    sgd = optimizers.gradient_descent_v2.SGD(learning_rate=learning_rate, momentum=momentum, decay=decay_rate,
    #配置SGD优化器
                                             nesterov=False)
    model.compile(loss='mse', optimizer=sgd)
    #编译模型，使用均方误差作为损失函数
    # fit network
    history = model.fit(train_X_LSTM, train_y, epochs=epochs, batch_size=batch_size, validation_data=(test_X_LSTM, test_y),
                        verbose=1, shuffle=False)
    yhat = model.predict(test_X_LSTM)
    #预测测试集数据
    yhat = yhat.reshape(len(yhat), 1)
                        #预测值写入
    print("yhat:",yhat)
    area= 'DS4'
    Flag = False
    ExportTopredict = "D:/EGA_LSTM-代码封装----总/EGA_LSTM-代码封装----总/LSTM_optimization/PO-result/curves/" + area + "-wid_gwo.csv"

    # 创建目录（如果不存在）
    os.makedirs(os.path.dirname(ExportTopredict), exist_ok=True)

    with open(ExportTopredict, 'a', newline='',encoding='utf8') as out:
        writer = csv.writer(out)
        if Flag == False:
            header = ["predict"]
            writer.writerow(header)
            a = [yhat]
            print("a",a)
            for value in np.array(a).flatten():
                writer.writerow([value])
        
        
        # writer.writerow(a)
    # ExportTopredict = "D:/EGA_LSTM-代码封装----总/EGA_LSTM-代码封装----总/LSTM_optimization/PO-result/curves/" + area + "-" + "wid_gwo" + ".csv"
    # with open(ExportTopredict, 'a', newline='\n') as out:
    #     writer = csv.writer(out, delimiter=',')
    #     if (Flag == False):  # 如果是第一次写入，则写入CSV文件的头部
    #         header = ["predict"]
    #         writer.writerow(header)
    #     a = [yhat]#创建结果行
    #     writer.writerow(a)
    #     out.close()
    # #调整预测结果形状
    test_y = test_y.reshape(len(test_y), 1)
    return calcul_indicator(test_y, yhat)
    #返回计算的指标
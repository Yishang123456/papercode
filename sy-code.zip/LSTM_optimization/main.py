import pandas as pd
import matplotlib.pyplot as plt  # 用来绘图的库
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
from math import sqrt
from sklearn.ensemble import AdaBoostRegressor
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras import optimizers
# from svm import SVR
from sklearn.svm import SVR
import numpy as np
import re
import os
import tsa as h_tsa
import clhro as h_clhro
import ao as h_ao
import IAO as h_IAO
import gwo as h_gwo
import wid_gwo as h_wid_gwo
#import iao1 as h_iao1
#import iao2 as h_iao2
import wid_ao as h_wid_ao

import datetime
import csv
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
import tensorflow as tf
from tensorflow.compat.v1 import InteractiveSession
config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
session = InteractiveSession(config=config)


#时间序列数据转换为监督学习问题的格式
def series_to_supervised(data, n_in=1, n_out=1, dropnan=True):
    #输入的时间序列数据，输入/输出数据的滞后时间步数
    n_vars = 1 if type(data) is list else data.shape[1]
    df = pd.DataFrame(data)
    cols, names = list(), list()
    # input sequence (t-n, ... t-1)
    
    #构造输入数列
    for i in range(n_in, 0, -1):
        cols.append(df.shift(i))
        names += [('var%d(t-%d)' % (j+1, i)) for j in range(n_vars)]
    
    #构造预测序列
    # forecast sequence (t, t+1, ... t+n)
    for i in range(0, n_out):
        cols.append(df.shift(-i))
        if i == 0:
            #预测的第一个时间步
            names += [('var%d(t)' % (j+1)) for j in range(n_vars)]
        else:
            names += [('var%d(t+%d)' % (j+1, i)) for j in range(n_vars)]
    # 合并列 put it all together
    agg = pd.concat(cols, axis=1)
    agg.columns = names
    # drop rows with NaN values
    if dropnan:
        agg.dropna(inplace=True)
    return agg



def selector(name, feat, label, opts):
    if name == "tsa":
        hh = h_tsa.tsa(feat, label, opts)
    elif name == "clhro":
        hh = h_clhro.clhro(feat, label, opts)
    elif name=="ao":
        hh=h_ao.ao(feat,label,opts)
    elif name=="IAO":
        hh=h_IAO.IAO(feat,label,opts)
    elif name=="gwo": 
        hh=h_gwo.gwo(feat,label,opts)
    elif name=="wid_ao":
        hh=h_wid_ao.wid_ao(feat,label,opts)
    elif name=="wid_gwo":
        hh=h_wid_gwo.wid_gwo(feat,label,opts)
    else:
        pass
    return hh
if __name__ == '__main__':
    N = 30  # number of particles 种群数
    T = 30  #普通算法的迭代次数（树种优化算法不用这个）
    
    #需要处理的数据区域名称
    areas = ['DS4']
    # indicator = ['EV','MAE','MSE','RMSE','R_square']
    # print(os.getcwd())
    # 如果是需要改动对比的算法，在这里进行改进即可
    
    #分类器名称列表
    classifers = ['EGA-LSTM']
    
    algorithm = ['wid_gwo'] #这里是算法选择 clhro是杂交水稻，tsa是树种优化算法
    # df = pd.DataFrame(columns=classifers, index=indicator)
    #df = pd.DataFrame()
    Flag = False
    
    for area in areas:
        # path = './{}/'.format(area)
        pre_data_df = pd.read_csv('D:/EGA_LSTM-代码封装----总/EGA_LSTM-代码封装----总/LSTM_optimization/data/8area_{}.csv'.format(area))
        # pre_data_df = pd.read_csv('./8area_{}.csv'.format(area))

        # 对每种方法进行遍历
        for method in classifers:
            opts = { 'N': N, 'T': T, 'classifier_name': method}
            #种群数 迭代次数 分类器名称
        
            ExportToFile = "D:/EGA_LSTM-代码封装----总/EGA_LSTM-代码封装----总/LSTM_optimization/PO-result/results/" + area + "-" + method + "-" + ".csv"
            #输出结果的文件路径
            ExportToFile2 = "D:/EGA_LSTM-代码封装----总/EGA_LSTM-代码封装----总/LSTM_optimization/PO-result/curves/" + area + "-" + method + "-" + ".csv"
            #曲线数据的文件路径
            data_df  =pre_data_df
            if method[:3]=='EGA':
                #如果前三个字母是EGA
                res = pd.read_csv('D:/EGA_LSTM-代码封装----总/EGA_LSTM-代码封装----总/LSTM_optimization/soea_EGA_templet/optPop/Chrom.csv',header=None)
                values = res.values
                #从文件中读取的特征选择结果
                features = data_df.columns[1:]
                #获取特征
                best_features = []
                #初始化最优特征子集
                best_features.append('label_M')

                #根据特征选择结果筛选出最佳特征
                for index in range(values.shape[1]):
                     if values[0][index] == 1:#筛选出来的特征，如果是1则选上，如果是0，则不选。
                         best_features.append(features[index])
                #保留选中的特征列
                data_df = data_df[best_features]

            elif method[:2] == 'HR':  # 如果方法是 HO
           # 读取河马优化算法选择的特征结果
                res = pd.read_csv('D:/EGA_LSTM-代码封装/EGA_LSTM-代码封装----总/LSTM_prediction/DS4/hrogwo_feature_selection_DS4.csv', header=None)
                values = res.values
                # 从文件中读取的特征选择结果
                features = data_df.columns[1:]  # 获取特征
                best_features = []
                # 初始化最优特征子集
                best_features.append('label_M')

                # 根据特征选择结果筛选出最佳特征
                for index in range(values.shape[1]):
                     if values[0][index] == 1:  # 筛选出来的特征，如果是1则选上，如果是0，则不选。
                          best_features.append(features[index])
                # 保留选中的特征列
                data_df = data_df[best_features]



            values = data_df.values
            values = values.astype('float32')
            #进行标准化的操作
            #将数据缩放到指定范围（0-1）
            scaler = MinMaxScaler(feature_range = (0,1))
            scaled = scaler.fit_transform(values)
           
            #将标准化后的数据转换成监督学习数据
            reframed = series_to_supervised(scaled,1,1)
            #删除部分列，删掉预测列
            reframed.drop(reframed.columns[[i for i in range(int(reframed.shape[1] / 2) + 1, reframed.shape[1])]], axis=1,inplace=True)

            #数据框架转化为numpy数组split into input
            values = reframed.values
            #划分特征（输入）
            feat = np.asarray(values[:,:-1])
            # a = int(feat.shape[0])
            # label = np.ones(feat.shape[0],1)
            #划分标签（输出）
            label = np.asarray(values[:,-1])

            # label = label.reshape((feat.shape[0], 1))

            #设置时间序列数据
            data = np.linspace(1, T, T)
            #生成一个从1到30的等间距数列，共30个点
            data = np.transpose(data)
            data = data.reshape((T, 1))
            #便利算法列表中的每个算法
            for alg in algorithm:
                for i in range(3):#对每个算法执行三次
                    print("----------------------{}-----------------------".format(i))
                    starttime = datetime.datetime.now()
                    #记录开始时间
                    result = selector(alg, feat, label, opts)
                    endtime = datetime.datetime.now()
                    #记录结束时间 算法执行时间
                    time = (endtime - starttime).seconds

                    params = result['params']#从结果中获取参数
                    curve = result['c']#曲线数据
                    fit = result['MSE']
                    EV = result['EV']
                    MAE = result['MAE']
                    RMSE = result['RMSE']
                    R_square = result['R_square']
                    curves = np.transpose(curve)#转置曲线数据
                    data = np.hstack((data, curves))

                       #这里是把结果写进文件里
                    with open(ExportToFile, 'a', newline='\n') as out:
                        writer = csv.writer(out, delimiter=',')
                        if (Flag == False):  # 如果是第一次写入，则写入CSV文件的头部
                            header = ["Dataset", "Optimizer", "classifierName", "fitness", "EV", "MAE", "RMSE", "R_square","params","particles","time"]
                            writer.writerow(header)
                        a = [area, alg, method, fit, EV, MAE, RMSE, R_square,params,N,time]#创建结果行
                        writer.writerow(a)
                    out.close()
                    
                    #将曲线数据写入文件
                    with open(ExportToFile2, 'a', newline='\n') as out:
                        writer = csv.writer(out, delimiter=',')
                            # if (Flag == False):  # just one time to write the header of the CSV file
                            # header = ["Serial Number","pso", "sca", "woa", "gwo", "igwo", "mscgwo", "hrogwo"]
                            # header = ["Serial Number",'igwo']
                        header = ["Serial Number", 'tsa']  ##,'gwo','msgwo','igwo'
                        writer.writerow(header)
                        writer.writerows(data)


                    Flag = True

            Flag = False

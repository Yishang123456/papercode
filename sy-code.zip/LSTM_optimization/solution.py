import numpy as np

class solution:
    def __init__(self):
        self.best = 0#存储最佳适应度值
        self.bestIndividual=[]#存储最佳个体
        self.convergence1 = []#存储收敛曲线1的数据
        self.convergence2 = []#存储收敛曲线2的数据
        self.optimizer=""#优化器的名称
        self.objfname=""#目标函数的名称
        self.startTime=0#算法开始的时间
        self.endTime=0#算法结束时间
        self.executionTime=0#算法执行时间
        self.lb=0
        self.ub=0
        self.dim=0
        self.popnum=0#种群维度
        self.maxiers=0#最大迭代次数
        self.trainAcc=None#训练集的准确度
        self.testAcc=None
        self.kappa =  None
        

class individual(object):
    def __init__(self, lb, ub, dim):
        # 对初试化的上下界进行判断：
        # 初始化个体的位置：
        # if lb == -1 and ub == 1:
        #     self.position = np.random.randint(0, 2, size=dim)
        # else:
        self.vector = np.random.uniform(lb, ub, size=dim) 
        #从一个均匀分布[low,high)中随机采样，注意定义域是左闭右开，即包含low，不包含high.
        self.position = np.random.randint(0, 2, size=dim) 
        #np.random.randint() 根据参数中所指定的范围生成随机 整数。

        self.lb = lb
        self.ub = ub
        self.dim = dim
        self.fitness = 0
        self.acc = 0#存储个体准确度
        self.trial = 0#存储个体的尝试次数

class MHRO_fea_individual(object):
    def __init__(self, lb, ub, dim, selected_fea):
        self.position = [0 for i in range(dim)]
        selected = [i for i in range(dim)]
        index = np.random.choice(selected, selected_fea, replace=False)
        for i in index:
            self.position[i] = 1
        self.position = np.random.randint(0, 2, size=dim)
        self.lb = lb
        self.ub = ub
        self.dim = dim
        self.fitness = 0
        self.acc = 0
        self.trial = 0

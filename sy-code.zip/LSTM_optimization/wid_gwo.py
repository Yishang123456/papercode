import numpy as np
from numpy.random import rand
from function import Fun
# import FS.functionHO
import math
import copy
import math
import numpy as np
from scipy.special import gamma
import matplotlib.pyplot as plt

# 初始化位置
def init_position(lb, ub, N, dim):
    X = np.zeros([N, dim], dtype='float')
    for i in range(N):
        for d in range(dim):
            X[i, d] = lb[0, d] + (ub[0, d] - lb[0, d]) * rand()
    return X


# 设置边界
def boundary(x, lb, ub):  # lb下界，ub上界
    if x < lb:
        x = lb
    if x > ub:
        x = ub

    return x


def wid_gwo(xtrain, ytrain, opts):
    # Parameters
    # Dimension
    dim = 6
    # Parameters
    ub = [0.1, 0.6, 200, 200, 256, 100]
    lb = [0.0001, 0, 10, 10, 32, 10]
    ub = np.array(ub)
    ub = ub.reshape((1, dim))

    lb = np.array(lb)
    lb = lb.reshape((1, dim))

    N = opts['N']
    max_iter = opts['T']

    # Initialize position
    X = init_position(lb, ub, N, dim)

    fit = np.zeros([N, 1], dtype='float')

    report = {}

    Xalpha = np.zeros([1, dim], dtype='float')
    Xbeta = np.zeros([1, dim], dtype='float')
    Xdelta = np.zeros([1, dim], dtype='float')
    Xworst = np.zeros([1, dim], dtype='float')  # 最差个体位置
    Falpha = float('inf')
    Fbeta = float('inf')
    Fdelta = float('inf')
    Fworst = float('inf')  # 最差个体的适应度
    #yhat = Fun(xtrain, ytrain, X, opts)['yhat']
    for i in range(N):
        result = Fun(xtrain, ytrain, X[i, :], opts)
        fit[i, 0] = result['MSE']
        #yhat_list.append(result['yhat'])  # 记录每个个体的测试集预测结果
        if fit[i, 0] < Falpha:
            Xalpha[0, :] = X[i, :]
            Falpha = fit[i, 0]
            report = result.copy()

        if fit[i, 0] < Fbeta and fit[i, 0] > Falpha:
            Xbeta[0, :] = X[i, :]
            Fbeta = fit[i, 0]
            
        if fit[i, 0] < Fdelta and fit[i, 0] > Fbeta and fit[i, 0] > Falpha:
            Xdelta[0, :] = X[i, :]
            Fdelta = fit[i, 0]

        if fit[i, 0] > Fworst:  # 找到最差个体
            Xworst[0, :] = X[i, :]
            Fworst = fit[i, 0]
        
    # Pre
    curve = np.zeros([1, max_iter], dtype='float')
    t = 0

    curve[0, t] = Falpha.copy()
    print("Iteration:", t + 1)
    print("Best (GWO):", curve[0, t])
    t += 1

    while t < max_iter:
        # Coefficient decreases linearly from 2 to 0
        a = 2 - t * (2 / max_iter)
        for i in range(N):
            for d in range(dim):
                # Parameter C (3.4)
                C1 = 2 * rand()
                C2 = 2 * rand()
                C3 = 2 * rand()
                # Compute Dalpha, Dbeta & Ddelta (3.5)
                Dalpha = abs(C1 * Xalpha[0, d] - X[i, d])
                Dbeta = abs(C2 * Xbeta[0, d] - X[i, d])
                Ddelta = abs(C3 * Xdelta[0, d] - X[i, d])
                # Parameter A (3.3)
                A1 = 2 * a * rand() - a
                A2 = 2 * a * rand() - a
                A3 = 2 * a * rand() - a
                # Compute X1, X2 & X3 (3.6)
                X1 = Xalpha[0, d] - A1 * Dalpha
                X2 = Xbeta[0, d] - A2 * Dbeta
                X3 = Xdelta[0, d] - A3 * Ddelta
                Xworst_influence = (1 - rand()) * Xworst[0, d]
                X[i, d] = (X1 + X2 + X3 + Xworst_influence) / 4
                
                # 边界检查
                X[i, d] = boundary(X[i, d], lb[0, d], ub[0, d])


        # Fitness
        for i in range(N):
            result = Fun(xtrain, ytrain, X[i, :], opts)
            fit[i, 0] = result['MSE']
            if fit[i, 0] < Falpha:
                Xalpha[0, :] = X[i, :]
                Falpha = fit[i, 0]
                report = result.copy()
            if fit[i, 0] < Fbeta and fit[i, 0] > Falpha:
                Xbeta[0, :] = X[i, :]
                Fbeta = fit[i, 0]
                
            if fit[i, 0] < Fdelta and fit[i, 0] > Fbeta and fit[i, 0] > Falpha:
                Xdelta[0, :] = X[i, :]
                Fdelta = fit[i, 0]
                
            if fit[i, 0] > Fworst:  # 更新最差个体
                Xworst[0, :] = X[i, :]
                Fworst = fit[i, 0]


        curve[0, t] = Falpha.copy()
        print("Iteration:", t + 1)
        print("Best (GWO):", curve[0, t])
        t += 1

    report['params'] = Xalpha

    report['c'] = curve


    return report